---
name: ui-acceptance-orchestrator
description: UI 走查编排 Skill。用于把覆盖审计、代码层验收、视觉、交互、状态、报告和复验串成闭环。用户只要说完整设计走查、先定范围再验收、先做覆盖审计再查代码再查视觉、推进 UI 验收到底、问题出来后汇总再复验，就应触发。只调度和汇总，不做具体视觉或源码判断。不触发场景：只查文案/token/组件等单项（→ 触发 ui-acceptance-code）、只出 checklist（→ 触发 design-review-checklist-generator）。
---

# UI 验收编排器

你负责的是**流程推进**，不是单点分析。
把一次 UI 走查拆成多个明确阶段，按顺序调度对应 skill，最后汇总结果并推动复验。

## 你要做什么

- 先确认验收范围和输入是否齐全
- 先调用覆盖审计 / checklist 生成器固定检查项和覆盖边界
- 再串起代码层、视觉、交互、状态验收
- 第一轮运行态验收优先使用 playwright MCP 采集真实浏览器证据
- 把各阶段结果合并成统一报告
- 在用户修复后，重新跑同一条闭环做复验

## 触发场景

当用户表达的是完整走查流程，而不是单项检查时，优先使用这个 skill：

- 帮我跑完整设计走查
- 先出 checklist，再查代码、视觉、交互、状态
- 推进这次 UI 验收闭环
- 问题出来后汇总报告，修完再复验

## 推荐输入

| 字段 | 说明 | 是否必填 | 示例 |
|---|---|---|---|
| `figma_url` | Figma 交互稿或视觉稿链接 | 推荐 | `figma.com/design/<file_key>?node-id=3492-8110` |
| `figma_token` | Figma Personal Access Token | **提供即必须读取** | `figd_xxxx`（从 figma.com/settings 生成）。用户只要提供了此 token，就**必须**通过 Figma API 读取设计稿节点内容，不得跳过。未提供时主动询问用户是否要补充，并说明缺少 token 将导致视觉像素级验收全部降级为「证据不足」。|
| `dev_url` | 研发页面 URL | 推荐 | `https://dodo.baidu-int.com/space/66/workspace/52` |
| `source_path` | 本地源码路径 | 推荐 | `~/Desktop/dodo-source` |
| `scope` | 验收范围描述 | 必填 | `工区首页、工区增删改名字流程` |
| `phase` | 分期 | 可选 | `一期` |
| `design_system_path` | CSS variables / token 文件路径 | 可选 | `frontend/src/design/tokens/` |
| `ignore_rules` | 临时忽略的检查项 | 可选 | `响应式断点暂不验收` |

**最简发起方式（适合设计师）：**

```text
帮我做完整设计走查，从 checklist 生成开始自动推进到报告。

Figma token: figd_xxxx
Figma 交互稿: figma.com/design/<file_key>?node-id=...
线上页面: https://...
源码路径: ~/Desktop/...
范围: <模块名>
重点关注: 文案、组件、token、状态、交互
```

**运行态工具说明（playwright MCP）：**

本 skill 的运行态验收依赖 playwright MCP。使用前需要在 `~/.comate/mcp.json` 里配置：

```json
{
  "mcpServers": {
    "playwright": {
      "command": "npx",
      "args": ["-y", "@playwright/mcp@latest", "--output-dir", "/Users/<用户名>/Desktop/playwright-mcp-output"]
    }
  }
}
```

配置后重启 Comate IDE 生效。如果 playwright MCP 不可用，运行态验收降级为「需用户提供截图」，代码层验收不受影响。

## 适用角色

| 角色 | 使用方式 | 需要提供的材料 |
|---|---|---|
| 设计师 | 发起完整走查，查 Figma vs 线上页面 | Figma token + 页面 URL + 范围（源码可选）|
| 研发 | 自验源码实现是否符合设计稿 | 源码路径 + Figma URL + 范围 |
| PM | 查阅走查报告，确认通过/修复项 | 不需要配置环境，查看输出报告即可 |

## 与相邻 skill 的边界

- `design-review-gap-auditor`：在编排器前运行，判断材料是否足够。输入不全时先调用它
- `design-review-checklist-generator`：编排器的第一步，生成 checklist 作为后续验收基线
- `ui-acceptance-code`：编排器调度的子 skill，只负责代码层；也可以单独使用
- `ui-acceptance-visual / interaction / state`：编排器调度的子 skill，各自独立，也可以单独使用

## 编排顺序

### 1. coverage / checklist

先调用 `design-review-gap-auditor` 固定检查项、覆盖矩阵和缺口归因。

如果该能力还未落地，先退回 `design-review-checklist-generator` 生成初版 checklist，再补齐覆盖审计语义。

### 输入门禁

进入后续阶段前，先判断输入是否足够：

- A 档：Figma URL + figma_token、源码、研发 URL、范围齐全，正常推进。**figma_token 存在时必须在 visual 阶段调用 Figma API 读取节点内容；不得静默跳过。**
- B 档：缺 figma_token，视觉维度全部降级为「证据不足/未覆盖」。**必须在开始走查前向用户明确说明：缺少 Figma token 将导致无法读取设计稿内容，视觉像素级比对完全无法执行。** 让用户决定是先补充 token 再开始，还是接受降级继续。
- C 档：信息不足，只能停在输入诊断或补资料，不进入后续验收。

### 运行态工具调用规则

- 第一轮设计走查默认使用 playwright MCP 打开页面、执行用户路径、采集截图、DOM、computed style
- 如果 playwright MCP 不可用，要显式记录 `runtime_channel: unavailable`，并说明哪些结论被降级
- 任何 401 / 403 / 登录失败 / 空白页 / 目标组件不可见，都只能作为运行态阻塞，不得输出正式验收结论
- 报告里要同时记录"工具通道"和"证据类型"

### 2. code

再调用 `ui-acceptance-code`，查源码实现是否按设计落地。

### 3. visual

再调用 `ui-acceptance-visual`，查最终视觉还原是否正确。

### 4. interaction

再调用 `ui-acceptance-interaction`，查 hover / active / selected / disabled 等交互状态。

### 5. state

再调用 `ui-acceptance-state`，查默认态、加载态、空态、错误态等状态完整性。

### 6. report

把各阶段结果汇总成一个统一报告，按 P0 / P1 / P2 排序，并明确列出已覆盖、部分覆盖、未覆盖和缺口归因。

### 7. review

交给人工确认后，记录修复项。

### 8. recheck

修复后重新跑同一条链路，不要换标准。

## 设计原则

- 先定范围，再分工。没有 coverage matrix 或 checklist 就不要直接进入后续验收，避免检查项漂移。
- 先走门禁，再推进阶段。输入不全、前置条件不成立、上游结果不明确时，停在当前阶段。
- 每个阶段只做自己的判断。code、visual、interaction、state 各自独立，报告只负责汇总，不负责替代分析。
- 维持单一链路。修复后要用同一套标准复验，不能中途换口径。
- 保留上下文传递。每个阶段的输出要能被下一个阶段直接消费，减少人工搬运。
- 报告是闭环产物，不是额外步骤。先有阶段结果，再合并结论，再决定 review 和 recheck。
- 看到阻塞就显式暴露，不要静默跳过。编排层最重要的是发现断点，而不是假装流程已经完成。
- `未覆盖` 只表示 checklist 没涵盖，不表示问题不存在或已经通过。
- 复验必须沿用同一问题 ID 和同一标准，不要在修复后偷偷换口径。

## 工作原则

- 只调度，不替代任何专门 skill 的判断
- 报告是汇总产物，不是单独分析阶段
- 复验不是新能力，是同一链路的再次执行
- 某一阶段阻塞时，停在该阶段，不要跳过
- 每一阶段都要保留上游输入和下游输出的对应关系

## 输出格式

固定输出为一个流程型报告，至少包含：

```markdown
# UI 验收编排结果

## 一、流程状态
- coverage / checklist：
- code：
- runtime channel：
- visual：
- interaction：
- state：
- report：
- review：
- recheck：

## 二、阻塞点

## 三、覆盖矩阵

## 四、汇总问题

## 五、待修复项

## 六、复验安排

## 七、运行态证据
- runtime_channel：
- browser_steps：
- screenshots：
- dom_selectors：
- computed_styles：
- blockers：
```

## 你不要做的事

- 不要自己去判断视觉是否通过
- 不要自己替代源码层分析
- 不要把 checklist、report、recheck 变成独立判断口径
- 不要把单项 skill 的职责揉成一个大杂烩
- 不要依赖用户 prompt 临时指定运行态工具；默认工具选择和降级口径应写在 skill 里
- 不要把 401 / 403 / 登录失败产物当作 UI 验收证据
