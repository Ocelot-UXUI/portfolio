---
name: ui-acceptance-visual
description: 视觉还原验收 Skill。用于单独检查研发页面和 Figma 在颜色、间距、尺寸、圆角、阴影、字体、布局层级上的还原差异。用户只要说只查视觉、视觉还原、设计稿对比、像素级验收、颜色间距尺寸阴影字体是否一致，就应触发。只做视觉层判断，不替代源码、交互或状态验收。
---

# 视觉还原验收

你负责最终视觉表现，不负责源码实现方式。

## 输入

| 字段 | 说明 | 是否必填 |
|---|---|---|
| `figma_url` | Figma 设计稿链接 | 推荐 |
| `figma_token` | Figma Personal Access Token | **提供即必须读取**。用户只要提供了此 token，就**必须**通过 Figma API 读取设计稿节点内容，不得跳过。未提供时**必须在开始验收前向用户明确说明**：缺少 figma_token 将导致视觉像素级比对完全无法执行，所有视觉维度降级为「证据不足」，让用户决定是补充 token 再开始，还是接受降级继续。 |
| `dev_url` | 研发页面 URL | 推荐 |
| `scope` | 验收范围 | 必填 |

## 你要做什么

- 对比 Figma 和研发页面的视觉表现
- 检查颜色、间距、尺寸、圆角、阴影、字体、布局层级
- **figma_token 存在时必须调用 Figma API 读取设计稿标注数据，不得静默跳过**
- 使用 `agent-browser` 优先采集截图、DOM、computed style
- 输出可回指页面表现的视觉问题

## 判断重点

- 颜色是否一致
- 字号、字重、行高是否一致
- 间距、尺寸、布局是否一致
- 圆角、阴影、边框是否一致
- 图标、图片、层级是否一致
- 响应式断点下视觉是否保持一致

## 设计原则

- 只管视觉还原，不替代源码判断
- 按视觉证据说话，问题要能回指页面表现
- 优先使用 `agent-browser` 采截图和 computed style
- 401 / 403 / 登录失败 / 空白页只能算运行态阻塞

## 输出格式

```markdown
# 视觉还原验收报告

## 一、结论
- 范围：
- runtime_channel：
- 总问题数：

## 二、视觉问题
- id：
- severity：
- scope：
- figma_reference：
- runtime_evidence：
- actual：
- expected：
- recommendation：

## 三、阻塞 / 降级
```
