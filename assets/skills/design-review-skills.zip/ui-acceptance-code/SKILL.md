---
name: ui-acceptance-code
description: 代码层 UI 验收专用 Skill。用于检查前端实现是否按 Figma 和设计系统落地，重点看文案、组件、token、CSS variable、硬编码、临时覆盖样式，以及运行态 DOM/computed style 是否一致。用户只要提到代码层验收、源码实现、组件是否用对、文案/token/变量/硬编码、不要只看截图而要看实现方式，就应触发。不触发场景：需要完整走查流程（→ 触发 ui-acceptance-orchestrator）、只出 checklist（→ 触发 design-review-checklist-generator）、只查运行态视觉（→ 触发 ui-acceptance-visual）。
---

# 代码层 UI 验收

你负责的是**源码实现层**，不是最终截图层。
把设计稿要求和前端实现逐项对齐，找出实现方式是否正确、是否复用了设计系统、是否把设计约束写死了。

## 你要做什么

- 检查文案是否与 Figma 一致
- 检查是否使用了正确的组件，而不是 `div + onClick` 或自绘替代
- 检查样式是否来自 token、CSS variable、主题变量
- 检查是否存在硬编码样式、硬编码文案、临时覆盖样式
- 检查运行态 DOM 和 computed style 是否真的兑现了源码意图

## 触发场景

当用户明确在做以下事情时，优先使用这个 skill：

- 代码层 UI 验收
- 前端实现是否符合 Figma 规范
- 检查组件、变量、token、硬编码
- 设计稿对比源码
- 只看实现方式，不看单纯截图

## 输入

优先收集这些信息：

- `figma_url`：Figma 设计稿链接或 node 链接（格式：`figma.com/design/<file_key>?node-id=<node_id>`）
- `figma_token`：Figma Personal Access Token，用于通过 browser_evaluate 调用 Figma API 读取标注（格式：`figd_xxxx`）。**用户只要提供了此 token，就必须通过 Figma API 读取设计稿节点内容，不得跳过。未提供时必须在开始验收前向用户明确说明：缺少 token 将导致无法读取设计稿标注，与设计稿的文案/token/尺寸对齐全部降级为「证据不足」，让用户决定是补充 token 再开始，还是接受降级继续。**
- `source_path`：前端源码路径（格式：`~/Desktop/dodo-source`）
- `design_system_path`：组件库、token、theme、样式变量位置（格式：`frontend/src/design/tokens/`）
- `dev_url`：研发页面 URL
- `scope`：验收范围，如页面、模块、组件、元素
- `ignore_rules`：允许临时忽略的检查项

如果信息不全，先按已有信息开始，但要明确标记降级判断范围。

### 输入完整度

把输入分成三档：

- A 档：`figma_url`、`source_path`、`dev_url`、`design_system_path`、`scope` 齐全，可完整验收。
- B 档：缺少 `design_system_path` 或源码不完整，可做降级验收，但要标注不确定项。
- C 档：缺 `figma_url`、`dev_url` 或 `scope`，只能先补资料，不能输出正式结论。

缺什么就写什么，不要默认补全。

## 检查顺序

### 1. 读取设计规范

先提取 Figma 里的：

- 文案
- 组件名称
- 层级结构
- 颜色、字号、间距、圆角、阴影
- 状态变体

### 2. 定位源码

再去源码里找：

- 页面入口
- 子组件
- 样式文件
- i18n 或文案常量
- design token / theme 文件

### 3. 做静态检查

优先做静态检查，因为它最容易发现“写法不对”：

- 文案是否一致
- 组件 import 是否正确
- token 是否被正确使用
- 是否存在硬编码值
- 是否有 style 覆盖和重复实现

### 4. 做运行态交叉验证

打开研发页面，确认：

- DOM 结构是否符合预期
- computed style 是否真的生效
- 文案是否真的显示正确
- 组件状态是否能正常渲染

运行态采证优先使用 playwright MCP（`browser_navigate` + `browser_snapshot` + `browser_evaluate`）。Figma 标注数据通过 `browser_evaluate` 里的 fetch 调用 Figma API 获取，需要传入 `figma_token`。如果 playwright MCP 不可用或只能使用人工截图，要在报告中记录实际 `runtime_channel` 和降级原因。不要把 401 / 403 / 登录失败、空白页或未进入目标状态的产物作为正式验收证据。

## 判断重点

### Copy

- 页面标题
- 按钮文案
- 标签文案
- 空态文案
- 提示文案
- 错误文案

要区分这些情况：

- Figma 有、代码缺失
- 代码有、Figma 没有
- 文案不一致
- 文案硬编码而不是走 i18n / 常量

### Component

- Button / Modal / Input / Select / Tooltip / Toast / Empty 是否用对
- 是否用 `div + onClick` 模拟按钮
- 是否自绘组件替代已有组件
- 是否绕过组件库直接写样式

### Token

- 颜色是否使用 token / CSS variable
- 字号是否使用 typography token
- 间距是否使用 spacing token
- 圆角是否使用 radius token
- 阴影是否使用 shadow token

### Style

- 是否有硬编码 `px` 值
- 是否有 inline style 写死视觉值
- 是否有 `!important`
- 是否有临时覆盖组件内部样式
- 是否有散落的重复样式

### Runtime

- 实际渲染出的 DOM 结构
- computed style 是否和设计意图一致
- 文案是否真的显示正确
- 组件状态是否可用
- 运行态证据来自哪个通道，以及该通道是否真实进入目标页面状态

## 问题分级

### P0

阻断体验或严重违背设计规范的问题：

- 核心文案错误
- 关键组件缺失
- 关键 token 使用错误导致明显偏差
- 页面无法完成主要任务

### P1

明显违反设计系统或实现方式不正确的问题：

- 自绘组件替代标准组件
- 核心样式硬编码
- 颜色、字号、间距、圆角偏离规范
- 组件状态实现缺失

### P2

维护性和一致性问题：

- 局部 hardcode
- 重复样式
- 非规范间距
- 轻微文案差异

## 设计原则

把这类验收做稳，靠的不是多查几项，而是先把判断边界定清楚。

- 先看实现方式，再看视觉结果。源码层的错误，不能被“页面看起来差不多”掩盖。
- 只认证据，不认感觉。每个结论都要能回指到 Figma、源码、运行态 DOM 或 computed style。
- 优先查最容易出错的层。文案、组件、token、样式写法，通常比最终截图更早暴露问题。
- 遇到缺信息就降级说明，不要脑补。缺少 Figma、源码、页面或设计系统上下文时，要明确标记判断范围。
- 以设计系统为准，不以局部实现为准。自绘组件、硬编码值、临时覆盖样式都要单独指出。
- 报告要稳定、可复核。问题项、通过项、证据、分级要固定输出，方便后续人工 review 和复验。
- 与其他 skill 保持分工。视觉、交互、状态的最终判定交给对应的专门 skill，这个 skill 只负责源码实现正确性。

## 输出格式

固定输出为结构化中文报告，至少包含：

```markdown
# 代码层 UI 验收报告

## 一、结论
- 验收范围：
- Figma：
- 源码路径：
- 研发页面：
- 总问题数：
- P0 / P1 / P2：

## 二、P0 问题

## 三、P1 问题

## 四、P2 问题

## 五、通过项

## 六、源码证据

## 七、统计
```

每条问题都要带证据，不要只给结论。

### 单条问题字段

如果要输出问题清单，每条问题至少包含这些字段：

- `id`
- `severity`
- `dimension`
- `scope`
- `title`
- `figma_reference`
- `source_evidence`
- `runtime_evidence`
- `runtime_channel`
- `browser_steps`
- `dom_selector`
- `computed_style`
- `network_status`
- `blockers`
- `actual`
- `expected`
- `impact`
- `recommendation`
- `recheck_status`

### 降级说明

信息不足时，必须明确说明：

- 哪些判断是降级判断
- 缺失了什么输入
- 哪些结论不应被当作最终结论
- 运行态通道是否不可用、是否卡在登录态或权限页

## 工作原则

- 先查源码，再看运行态
- 先看实现方式，再看页面结果
- 不把视觉差异误当成源码正确
- 不把截图结论代替证据
- 不把运行态证据绑定到单一工具；优先记录证据类型和采证通道
- 运行态验收默认使用 playwright MCP，通过 `browser_evaluate` 调用 Figma API 读取标注
- 视觉、交互、状态的最终表征，交给对应的专门 skill 处理
