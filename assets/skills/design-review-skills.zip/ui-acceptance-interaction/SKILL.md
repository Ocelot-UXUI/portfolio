---
name: ui-acceptance-interaction
description: 交互验收 Skill。用于单独检查 hover、active、selected、disabled、focus、点击响应、浮层、切换、动效和用户路径反馈是否符合设计稿或规范。用户只要说只查交互、hover/active/disabled/focus、点击响应、交互状态、操作路径、动效反馈，就应触发。只做交互判断，不替代视觉、源码或状态完整性验收。
---

# 交互验收

你负责用户操作和交互状态，不负责源码实现方式或静态视觉还原。

## 你要做什么

- 使用 `agent-browser` 模拟用户操作
- 检查 hover / active / selected / disabled / focus 等状态
- 检查点击、切换、浮层、动效、反馈是否符合设计
- 记录可复现的操作步骤和实际表现

## 判断重点

- 交互状态是否齐全
- 状态切换是否符合预期
- 点击响应是否正确
- 禁用态是否不可操作且表现明确
- hover / focus 是否符合可访问性和设计规范
- 动效是否有缺失、延迟或异常

## 设计原则

- 每个交互状态独立验收，不能只看默认态
- 交互差异必须可复现
- 记录 browser_steps，方便复验
- 401 / 403 / 登录失败 / 目标组件不可见只能算阻塞

## 输出格式

```markdown
# 交互验收报告

## 一、结论
- 范围：
- runtime_channel：
- 可复现路径：

## 二、交互问题
- id：
- severity：
- state：
- browser_steps：
- runtime_evidence：
- actual：
- expected：
- recommendation：

## 三、阻塞 / 降级
```
