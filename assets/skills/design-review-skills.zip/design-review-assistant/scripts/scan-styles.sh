#!/bin/bash
# 快速样式扫描脚本
# 在项目目录中执行，提取样式值供 Step 3 代码扫描使用
# 用法：bash scan-styles.sh [项目路径] [--output-format text|json]

PROJECT_DIR="${1:-.}"
OUTPUT_FORMAT="${2:-text}"

if [ ! -d "$PROJECT_DIR" ]; then
  echo "错误：项目路径 $PROJECT_DIR 不存在"
  exit 1
fi

cd "$PROJECT_DIR" || exit 1

echo "🔍 扫描项目：$(pwd)"
echo ""

# 1. 颜色
echo "=== 颜色值 ==="
rg --no-heading -n '#[0-9a-fA-F]{6}\b' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -50

# 2. 字号
echo ""
echo "=== 字号 ==="
rg --no-heading -n 'font-size:\s*[\d.]+(px|rem)' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -30

# 3. 间距
echo ""
echo "=== 间距 (padding/margin/gap) ==="
rg --no-heading -n '(padding|margin|gap):\s*[\d.]+(px|rem)' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -40

# 4. 圆角
echo ""
echo "=== 圆角 ==="
rg --no-heading -n 'border-radius:\s*[\d.]+(px|%)' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -20

# 5. 阴影
echo ""
echo "=== 阴影 ==="
rg --no-heading -n 'box-shadow:' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -20

# 6. CSS Variables 定义
echo ""
echo "=== CSS Variables (--*) ==="
rg --no-heading -n '--[\w-]+:\s*[^;]+' --type-add 'web:*.{css,less,scss}' -t web 2>/dev/null | head -40

echo ""
echo "✅ 扫描完成"