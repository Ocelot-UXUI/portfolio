---
name: design-review-assistant
description: >-
  IDE 设计走查助手。在 Comate AI IDE 内完成前端代码与 Figma 设计稿/设计规范文档的交互视觉验收走查。
  何时使用：用户提供 Figma 设计稿链接 或 设计规范文档（Ku 链接/本地文档/粘贴规范文本）+ iCode/GitHub 仓库地址或本地代码路径，需要：
  (1) 提取设计规范基准（从 Figma 或文档中提取 design token、变量、规范值）；
  (2) 扫描代码中实际样式值进行比对；
  (3) 标记视觉差异并提供直接修复；
  (4) 输出改动汇总，支持提 CR 或截图同步。
  触发词：设计走查、视觉验收、走查、Figma 对比、验收设计稿、IDE 走查、样式比对、视觉审计、规范走查、对照规范。
  【注意】本技能不会自动截取页面截图做像素级对比，而是通过提取设计 token 与代码 token 进行语义化比对。
---

# IDE 设计走查助手

在 **Comate AI IDE** 中，将 Figma 设计稿 **或** 设计规范文档（设计指南、视觉规范、Style Guide 等）与前端代码的实际样式进行比对，发现差异并直接修复。

走查基准来源不限 —— 有 Figma 链接就用 Figma 提取 token，有规范文档就从文档提取规范值，什么都没有也可以用户手动粘贴关键值。

## 核心原则：先定范围，再看代码

**范围越精确，token 越省，速度越快。** 进入任何步骤前，先在 Step 0 确定走查范围，
后续所有步骤（代码扫描、Token 比对、修复）都只在这个范围内操作。

### 各范围模式的 token 消耗参考

| 模式 | 扫描范围 | 适用场景 | 相对 token |
|------|---------|---------|-----------|
| 🔵 按提交/CR | `git diff` 改动的文件 | 上线前的最后一次验收 | ★（最省） |
| 🟢 按模块/目录 | 指定路径下的文件 | 新功能模块开发中 | ★★ |
| 🟡 按组件 | Grep 匹配到的组件文件 | 组件库统一走查 | ★★ |
| 🟠 按样式类别 | 只扫某一类属性（如只查颜色） | 快速单项核对 | ★ |
| 🔴 全量走查 | 项目所有样式文件 | 首次接入 / 大版本重构 | ★★★★★ |

## 总流程

```
输入（Figma URL / 设计规范文档 + 代码路径 + 范围描述）
  → Step 0 范围判定 → 锁定文件集合 / 行范围
  → Step 1 环境就绪（拉代码 + 自动检测技术栈 + 启动）
  → Step 2 提取走查基准（Figma API / 文档解析 / 用户粘贴，三选一）
                     ↓ 得到结构化规范基准（token.json + spec.md）
  → Step 3 代码样式扫描（仅在锁定范围内扫描）
  → Step 4 Token 比对（标记一致 / 差异 / 缺失）
  → Step 5 修复与验证（定位代码 → 修复 → 即时验证）
  → Step 6 交付（改动汇总 + CR / 截图同步）
```

---

## Step 0：范围判定（最省 token 的关键入口）

**优先级最高的一步。** 用户的一句话里可能同时包含多种范围信息，按以下优先级判定。
一旦范围锁定，后续所有 I/O（代码拉取、文件扫描、比对）都**只在这个范围内操作**。

### 0a：解析范围模式

从用户消息中提取范围关键词，按优先级匹配：

| 优先级 | 模式 | 触发词示例 | 文件锁定方式 |
|--------|------|-----------|------------|
| 🔵 P0 | **按 Commit/CR** | 「这次提交」「这个 CR」「commit xxx」「改动」「changeId xxx」 | `git diff <commit>^..<commit>` 或 `git diff <base>...<head>`，只分析 diff 行涉及的样式 |
| 🟢 P1 | **按模块/目录** | 「走查xxx页面」「pages/xxx」「模块xxx」「某个功能模块」「目录xxx」 | 将扫描路径限定在 `src/pages/xxx/` 或 `src/components/xxx/` |
| 🟡 P2 | **按组件** | 「Button 组件」「Card」「导航」「搜索框」「走查一下xxx」 | Grep 组件名匹配组件文件（`.tsx` / `.jsx` / `.module.css`） |
| 🟠 P3 | **按样式类别** | 「只查颜色」「只看字号」「检查间距」「对一下圆角」「查阴影」 | 扫描时 Grep 只匹配对应 CSS 属性 |
| 🔴 P4 | **全量走查**（默认） | 无以上任何范围限定词 | 项目所有样式文件 |

### 0b：各范围模式的文件锁定策略

#### 🔵 P0 — 按 Commit/CR（最省，推荐）

```
用户说：对这次提交做设计走查，commitId 是 abc1234
↓
git diff abc1234^..abc1234 --stat          ← 先看改了哪些文件
git diff abc1234^..abc1234 -- '*.css' '*.less' '*.scss' '*.tsx' '*.jsx'  ← 只看样式相关
↓
锁定范围 = diff 中涉及样式变更的文件 + 变更行号
```

- **不扫描** diff 范围外的任何代码
- **Token 消耗 ≈ 改动量级**，与项目大小无关
- 如果是 CR 链接，先用 `icode-content-fetcher` 获取 CR 的 diff 信息再锁定

#### 🟢 P1 — 按模块/目录

```
用户说：走查 pages/DetailPage 这个模块
↓
锁定路径 = src/pages/DetailPage/**
```

- 只 Glob/Grep 该路径下的样式文件
- 如果是组件目录，同时包含 `.tsx`/`.jsx` + `.css`/`.module.css`

#### 🟡 P2 — 按组件

```
用户说：对一下 Button 组件
↓
Grep 查找：文件名含 Button 或类名含 button 的文件
锁定文件列表
```

- 搜索策略：`**/Button*.tsx`、`**/Button*.module.css`，以及代码中引用的子组件

#### 🟠 P3 — 按样式类别

```
用户说：只查颜色
↓
Grep 模式：#[0-9a-fA-F]{6}\b | rgb\( | hsl\( | var\(--color-
跳过：字号、间距、圆角、阴影的扫描
```

- 与 P0/P1/P2 **叠加使用**：如「查这次提交的颜色」= P0 + P3
- 单查某类时，Grep 模式精确匹配，不加载无关属性

### 0c：范围叠加规则

多种范围可组合，叠加后范围取交集：

| 组合 | 效果 | 省 token 程度 |
|------|------|-------------|
| P0 + P3 | 只查某次提交中的**颜色**变更 | ★★★★★ |
| P1 + P3 | 只查某个模块的**字号** | ★★★★★ |
| P0 + P1 | 只查某次提交中改到的**某个模块** | ★★★★ |
| P1 + P2 | 查某个模块下的**某个组件** | ★★★★ |

### 0d：输出范围声明

范围锁定后，**必须先输出范围声明给用户确认**，之后再进入 Step 1：

```
📐 走查范围已锁定
模式：按提交（P0）+ 按样式类别（P3）
提交：abc1234（"feat: 新增详情页信息卡片"）
变更文件：3 个（2 个 CSS，1 个 TSX）
扫描类别：仅颜色
涉及行数：约 15 行
预估范围：极小（★）
```

这能让用户感知到范围是否准确，避免扫错了或扫漏了。

---

## Step 1：环境就绪

### 1a：获取代码到本地

根据 Step 0 确定的范围模式，选择性拉取：

| 来源 | 全量 / 模块模式 | 按提交模式 |
|------|----------------|-----------|
| iCode URL | 完整 clone 仓库 | 可用 `--depth=1` 浅 clone + fetch 目标 commit |
| GitHub URL | 完整 clone | 同上 |
| 本地路径 | 直接使用 | 直接使用 |
| **代码获取量** | 完整仓库 | 仅含目标 commit 及之前的必要历史 |

### 1b：自动检测技术栈

在项目根目录检测以下内容（用 Glob + Grep 工具）：

| 检测项 | 检测方法 | 判定 |
|--------|---------|------|
| 框架 | `package.json` | React / Vue / Angular / 其他 |
| 样式方案 | 配置文件存在性 | Tailwind / CSS Modules / Styled Components / Less/SCSS |
| 组件库 | `package.json` dependencies | antd / Radix+shadcn / Material UI / 自研 |
| 构建工具 | 配置文件存在性 | Vite / Next.js / Webpack |
| **Token 系统** | 见 1c | CSS Variables / Tailwind config / JSON tokens / 无 |

### 1c：自动检测 Token 系统（关键）

> 详见 `references/token-detection.md`

搜索顺序：
1. `token.json` / `tokens.json` / `design-tokens.json` 等标准命名
2. `theme.css` / `variables.css` / `tokens.css` 等含 `:root { --* }` 的文件
3. `tailwind.config.*` 中的 `theme.extend.colors / spacing / borderRadius` 等
4. `style-dictionary` / `theem` 等 token 管理工具的配置文件
5. 组件代码中高频出现的硬编码样式值（无 token 系统的兜底检测）

输出一份 **当前代码实际设计规范摘要**：
```
项目：xxx
框架：React + TypeScript
样式：CSS Modules
组件库：自研（无第三方 UI 库）
Token 系统：CSS Variables（token.json + theme.css）
检测到 token 数：颜色 12 个，间距 8 个，字号 6 个，圆角 4 个，阴影 3 个
未使用 token 的硬编码样式：约 15 处（主要集中在 Card 组件和 DetailPage）
```

### 1d：启动开发服务器

- 检测 `package.json` 中的 `scripts.dev` / `scripts.serve` / `scripts.start`
- 优先使用 `npm run dev`，如不支持则询问用户如何启动
- 告知用户开发服务器 URL（方便设计师在浏览器中同步查看）

---

## Step 2：提取走查基准

走查基准的来源有三种模式，按优先级尝试：

```
优先级 ①  Figma 链接 → 通过 Figma API 提取 token/变量/组件规格
优先级 ②  规范文档   → 从 Ku 文档/本地文件/PDF/粘贴文本中解析规范值
优先级 ③  用户手动   → 用户直接粘贴关键值，Skill 结构化存储
```

### 2a：判断基准来源模式

从用户输入中判断走查基准的来源：

| 来源 | 触发 | 优先级 |
|------|------|--------|
| **Figma URL** | 消息含 `figma.com/design/` | ①（优先） |
| **规范文档链接** | Ku 链接 / 附件 / 本地文档路径 | ② |
| **规范文本粘贴** | 用户直接粘贴了规范内容 | ② |
| **人工提供值** | 用户说"颜色用 #1890ff，间距 16px"等 | ③ |

**优先级规则**：用户同时提供多个来源时，按上表优先级取最高者。
如果用户说"我有 Figma 也有规范文档"，优先用 Figma（结构化数据更准）。
如果 Figma 尝试失败，自动降级到文档模式。

### 2b：解析 Figma URL（来源 ①）

> 详见 `references/figma-integration.md`

**优先路径**：尝试通过 `figma-token-extractor` 能力提取设计数据。
**兜底路径**：如果 Figma MCP 不可用，引导用户提供 Figma Personal Access Token（PAT）。

数据提取内容（渐进式）：

| 层级 | 内容 | 方法 |
|------|------|------|
| L1 - Token/变量 | 颜色、字号、间距、圆角、阴影等 Design Token | `figma-remote-mcp.get_variable_defs()` 或 REST `/variables/local` |
| L2 - 组件规格 | 组件名称、尺寸、padding、子结构 | `get_metadata(nodeId)` 或 REST `/files/:key/nodes` |
| L3 - 组件截图 | 视觉截图（辅助人工对比） | `get_screenshot(nodeId)` 或 `get_image(nodeId)` |

### 2c：生成本地 Figma 基准文件

将提取到的 Figma 设计数据写入本地参考文件（**不走 figma-token-extractor 的全量生成流程，仅提取 token 做比对基准**）：

```
.design-review/
├── figma-tokens.json      ← Figma Design Token（SSOT 来源）
├── figma-tokens.md         ← 可读的 Token 对照表
└── figma-overview.md       ← 设计稿结构概览（页面/组件清单）
```

如果 Figma 完全无法连接（无 MCP 无 PAT），自动降级到文档模式（见下方 2d）。

### 2d：从规范文档提取基准（来源 ②）

当没有 Figma 链接，但用户提供了设计规范文档时使用。文档来源支持：

| 文档形式 | 获取方式 |
|---------|---------|
| **Ku 文档链接** | `ku-doc-manage` 读取文档内容 |
| **本地点 md/docx/pdf 文件** | Read 或 `pdf` Skill 读取 |
| **附件上传** | 从 `/home/gem/workspace/attachments/` 读取 |
| **用户粘贴文本** | 直接解析用户消息中的规范内容 |

**提取策略**：从文档中解析出结构化的设计规范值

从非结构化文档中提取设计规范时，使用自然语言理解 + 正则模式匹配来识别：

| 规范类别 | 文档中可能的表述 | 提取结果 |
|---------|----------------|---------|
| **颜色** | 「主色：#1890ff」「品牌色 #1677ff」「--color-brand: #1677ff」 | `--color-brand: #1677ff` |
| **字号** | 「正文 14px」「标题字号 16/20/24」「字体层级」 | `--font-size-body: 14px` |
| **间距** | 「卡片内边距 16px」「页面边距 24px」「间距 4n 递增」 | `--spacing-card: 16px` |
| **圆角** | 「圆角 8px」「大圆角 12px」「按钮圆角 4px」 | `--radius-md: 8px` |
| **阴影** | 「卡片阴影 0 2px 8px rgba(0,0,0,0.15)」 | `--shadow-card: 0 2px 8px` |
| **布局规则** | 「导航栏高 56px」「侧边栏宽 240px」 | 布局约束记录 |

**输出结构化基准文件**：

```
.design-review/
├── spec-tokens.json        ← 从文档提取的 Design Token（参考标准）
├── spec-tokens.md           ← 可读的规范对照表
└── spec-rules.md            ← 文档中的布局/行为规则（如"导航栏高度56px"）
```

输出时需标注置信度：
- 文档中明确标注的 → ✅ 高置信度
- 从表述中推断的 → ⚠ 中置信度（在 spec-tokens.md 中标注推断来源）
- 文档未覆盖的 → 🔍 缺失（走查报告中标注「规范未定义」）

### 2e：人工提供值（来源 ③）

用户直接说「颜色用 #1890ff，间距 16px，圆角 8px」时：

1. 从用户消息中正则提取所有 `属性: 值` 对
2. 结构化写入 `.design-review/manual-specs.json`
3. 后续比对逻辑不变，仅标注值来源为「人工提供」

---

## Step 3：代码样式扫描

> 详见 `references/code-scanning.md`

### 3a：在锁定范围内扫描

根据 Step 0 确定的范围，决定扫描的路径和模式：

| 范围模式 | 扫描范围 | 操作 |
|---------|---------|------|
| P0 按提交 | 只扫 diff 中变更行 | `git diff <commit>^..<commit> -- '*.css' '*.less' '*.scss' '*.tsx' '*.jsx'`，提取增减行中的样式值 |
| P1 按模块 | 限定路径 | `src/pages/xxx/**` 或 `src/components/xxx/**` |
| P2 按组件 | 匹配到的文件 | 组件名匹配的文件列表 |
| P3 按类别 | 只扫特定属性 | 见下方"扫描类别" |
| P4 全量 | 项目所有样式文件 | 所有样式文件 |

**关键约束**：
- P0 模式下，**不看 diff 以外的任何文件**
- P1/P2 模式下，扫描路径外的一律跳过
- P3 可与其他模式叠加（如 P0+P3 = 只看这次提交的颜色变更）
- ⛔ 不得在锁定范围外额外读取文件做"顺便检查"

### 3b：按类别扫描（仅当 P3 或叠加 P3 时）

当只检查某一类样式属性时，精确匹配 Grep 模式，不扫无关属性：

| 类别 | Grep 模式（仅示例，实际执行时灵活使用） |
|------|----------------------------------------|
| 颜色 | `#[0-9a-fA-F]{6}\b`、`rgb\(`、`hsl\(`、`var\(--color`、`var\(--bg` |
| 字号 | `font-size:\s*[\d.]+(px\|rem)` |
| 间距 | `(padding\|margin\|gap):\s*[\d.]+(px\|rem)` |
| 圆角 | `border-radius:\s*[\d.]+(px\|%)` |
| 阴影 | `box-shadow:\s*` |
| 边框 | `border(-width)?:\s*[\d.]+px` |

| 类别 | 扫描内容 |
|------|---------|
| 颜色 | `#RRGGBB`、`rgb()`、`hsl()`、命名颜色 |
| 字号 | `font-size: *px`、`font-size: *rem` |
| 间距 | `padding/margin/gap: *px/rem` |
| 圆角 | `border-radius: *px` |
| 阴影 | `box-shadow` |
| 边框 | `border: *px solid`、`border-width` |

扫描范围：
- `src/` 或 `components/` 下的所有样式文件（`.css` / `.less` / `.scss` / `.module.css`）
- 组件文件（`.tsx` / `.jsx`）中的内联样式（`style={{}}` / `styled-components`）
- Tailwind 类名（`className="..."`）

### 3c：语义提取与归类

将扫描到的值按语义归类，与 Step 2 的 Figma token 对齐：

```
颜色：
  #1890ff 出现 23 次 → 候选主色（Figma: --color-brand=#1677ff）⚠ 偏差
  #ffffff 出现 56 次 → 白色背景（Figma: --color-bg-base=#ffffff）✓ 一致
  #f5f5f5 出现 12 次 → 页面背景（Figma: --color-bg-secondary=#f0f0f0）⚠ 偏差

字号：
  14px 出现 31 次 → 正文（Figma: --font-size-body=14px）✓ 一致
  16px 出现 15 次 → 标题（Figma: --font-size-h4=16px）✓ 一致
  12px 出现 8 次 → 辅助文字（Figma: 无对应 token）‼ 代码有 Figma 无

间距：
  16px 出现 27 次 → 卡片内边距（Figma: --spacing-card=16px）✓ 一致
  24px 出现 5 次 → 页面边距（Figma: --spacing-page=20px）⚠ 偏差
```

---

## Step 4：Token 比对与差异分析

### 4a：比对规则

| 标记 | 含义 | 条件 |
|------|------|------|
| ✅ **一致** | 代码值与 Figma token 值匹配 | 完全一致 |
| ⚠ **偏差** | 代码值与 Figma 值不同 | 差值在合理范围 |
| ❌ **错误** | 代码值与 Figma 值显著不同 | 明显不符合设计稿 |
| ‼ **缺失** | 代码中存在的值在 Figma 无对应 | 可能是新增或 Figma 未覆盖 |
| 🔍 **未知** | Figma 有 token 但代码中未找到 | 遗漏了设计规范 |

### 4b：输出差异报告

生成一份**走查差异报告**，按严重程度排序，精确到文件行号：

```
═══════════════════════════════════════════
  🎨 IDE 设计走查报告
  项目：xxx | 日期：2026-06-12
═══════════════════════════════════════════

🔴 严重差异（2 处）
  1. src/components/Card/index.module.css:42
     → border-radius: 12px（Figma 规范：8px）
  2. src/pages/DetailPage/index.module.css:78
     → background: #1890ff（Figma 规范：--color-brand=#1677ff）

🟡 轻微偏差（3 处）
  3. src/layouts/Sidebar/index.module.css:15
     → width: 220px（Figma：208px）
  ...

🟢 一致项（12 项）
  ✓ 颜色匹配 6/8
  ✓ 字号匹配 4/4
  ✓ 间距匹配 5/6
  ✓ 圆角匹配 2/3

📊 整体一致性评分：78%
```

---

## Step 5：修复与验证

### 5a：逐项修复（根据用户确认）

对每一处差异，**询问用户是否修复**，用户确认后：

1. 定位源代码位置（精确到行）
2. 根据 Figma token 值修正样式
3. 如果用到了 Token 系统，优先替换为 CSS Variable 引用

修复类型：

| 场景 | 修复方式 |
|------|---------|
| 硬编码值 → Token | 替换为 `var(--xxx)` |
| 错误值 → 正确值 | 替换为 Figma 规范值 |
| 缺少样式属性 | 补充正确的属性值 |

### 5b：即时验证

每次修复后：
1. 确认文件修改正确（Read 验证）
2. 建议用户刷新浏览器查看效果
3. 记录修复结果

### 5c：批量修复（可选）

如用户希望一次性修复全部 / 某类差异，支持批量操作。

---

## Step 6：交付

### 6a：生成改动汇总

所有修复完成后，输出一份**修改汇总**：

```
═══════════════════════════════════════════
  📋 设计走查修改汇总
  项目：xxx | 日期：2026-06-12
═══════════════════════════════════════════

修改文件：3 个
  M src/components/Card/index.module.css   (+2 -1)
  M src/components/Button/index.module.css (+1 -1)
  M src/pages/DetailPage/index.module.css  (+1 -1)

具体修改：
  1. Card 圆角 12px → 8px（var(--radius-md)）
  2. 按钮主色 #1890ff → #1677ff（var(--color-brand-default)）
  3. 详情页间距 24px → 20px（var(--spacing-page)）

未修复项（用户跳过）：
  1. 侧边栏宽度 220px（Figma 208px）— 需产品确认
```

### 6b：提 CR（Code Review）

> 详见 `references/fix-and-commit.md`

如用户选择提 CR：

1. `git add` 修改的文件
2. 使用 `icode-git-commit` 生成符合规范的 commit message，关联 iCafe 卡片
3. `git push` 推送到远端
4. 使用 `icode-review-assistant` 发起代码评审
5. 提供 CR 链接给设计师和研发

### 6c：截图同步

如用户选择截图同步：

1. 告知用户浏览器截图 + 修改汇总发如流群
2. 将修改汇总内容格式化为清晰的消息文案
3. 可使用 `infoflow-notify` 发送通知或指导用户在如流中同步

---

## Pitfalls（必读）

1. ⛔ **范围优先于一切**——不要在未确定范围的情况下直接进入代码扫描，否则会全量读文件，浪费大量 token
2. ⛔ **P0 按提交模式不得看 diff 外的文件**——即使"顺便看看相关组件"也不行，必须严格遵守锁定范围
3. ⛔ **用户没说范围时，默认全量模式但必须主动询问是否需要缩小范围**（"本次走查范围比较大，要不要先限定某个模块或这次提交？"），不要默默开始全量扫
4. ⛔ **不要** 在 Figma 无法连接时放弃——进入人工辅助模式，让用户手动提供关键值
5. ⛔ **不要** 全量读取大文件（>500 行的样式文件）——用 Grep 精准定位后再按需读取
6. ⛔ **不要** 一次性展示所有差异——按严重程度分批展示，每次让用户确认
7. ⛔ **不要** 修改 JS 业务逻辑——走查只动样式层（CSS / Token / 类名）
8. ⛔ **不要** 用 `figma-token-extractor` 的全量生成流程——只提取 token 做比对，不生成组件代码
9. ⛔ **不要** 在没有用户确认的情况下直接修改代码——每处修改前必须询问
10. ⛔ **不要** 在无 token 系统的项目中强行引入 CSS Variables——优先用注释标记差异值，让用户决定修复方式
11. ⛔ **不要** 把文档中的模糊描述当作精确规范——如果文档写的是「深蓝色」而不是具体色值，标注为中置信度，不强转
12. ⛔ **文档覆盖不全时不要强制推进**——规范文档未覆盖的属性（如未定义阴影），走查报告中标注「规范未定义」，跳过比对
13. ⛔ **多来源不一致时以优先级高的为准**——Figma token > 规范文档 > 人工提供值，低优先级的值用于补充而非覆盖

---

## 参考文档

- **Token 自动检测**: 见 `references/token-detection.md`
- **Figma 集成**: 见 `references/figma-integration.md`
- **代码扫描策略**: 见 `references/code-scanning.md`
- **修复与提 CR**: 见 `references/fix-and-commit.md`

## 辅助脚本

- **样式扫描脚本**: 见 `scripts/scan-styles.sh`（快速提取项目中的样式值）