# Figma 集成

本 Skill 在 Step 2 中使用，用于从 Figma 提取 Design Token 作为走查基准。

## 核心原则

本 Skill 仅从 Figma **提取走查所需的基准数据**，不走 `figma-token-extractor` 的全量代码生成流程。

## 数据源连接

### 路径 A：通过 Figma MCP 连接（优先）

当前环境可能已配置以下 MCP（如果可用）：

```
figma-remote-mcp.get_variable_defs(nodeId)  → Design Variables
figma-remote-mcp.get_metadata(nodeId)        → 节点元数据
figma-remote-mcp.get_screenshot(nodeId)      → 节点截图
```

也支持 Figma Make MCP 的兼容接口。

### 路径 B：Figma REST API（兜底）

使用 Figma Personal Access Token（PAT），通过 REST API 获取：

```
GET /v1/files/{fileKey}/variables/local          → 本地变量定义
GET /v1/files/{fileKey}/nodes?ids={nodeId}       → 节点详情
GET /v1/files/{fileKey}/styles                   → 样式列表
```

**PAT 安全规则**：
- PAT 仅保存在会话内存
- 禁止写入任何文件
- 调用时通过 `-H "X-Figma-Token: <PAT>"` 内联传递
- 会话结束自动丢失

### 路径 C：人工辅助模式

当 MCP 和 REST API 均不可用时：

1. 告知用户当前无法自动连接 Figma
2. 邀请用户手动提供设计规范值（至少提供以下关键信息之一）：
   - 设计规范文档的 Ku 链接
   - 关键颜色值（主色、背景色、文字色等）
   - 关键字号和间距值
   - 组件截图或设计稿截图
3. 进入**人工辅助比对模式**：用户提供值作为基准，Skill 仍可完成代码扫描和比对

## 数据提取内容

### L1：Design Variables（必须）

| 类别 | API 字段 | 用途 |
|------|---------|------|
| 颜色 | variable.resolvedValues.color | 颜色比对基准 |
| 字号 | variable.resolvedValues.fontSize | 字号比对 |
| 间距 | variable.resolvedValues.space | 间距比对 |
| 圆角 | 节点属性 cornerRadius | 圆角比对 |
| 阴影 | variable.resolvedValues.shadow / 节点属性 | 阴影比对 |

### L2：组件规格（建议）

提取每个 Frame/Component 节点的：
- `name`（组件名称）
- `width` / `height`（尺寸）
- `paddingLeft` / `paddingRight` / `paddingTop` / `paddingBottom`
- `itemSpacing`（子元素间距）
- `cornerRadius`
- `children` 结构

### L3：截图（辅助）

当 MCP 可用时，获取节点截图作为人工对照参考。

## 基准文件格式

提取后写入 `.design-review/figma-tokens.json`：

```json
{
  "meta": {
    "source": "figma-remote-mcp",
    "fileKey": "xxx",
    "nodeId": "1:23",
    "extractedAt": "2026-06-12T19:33:00"
  },
  "variables": {
    "color": {
      "brand-default": { "value": "#1677ff", "type": "color" },
      "bg-base": { "value": "#ffffff", "type": "color" },
      "bg-secondary": { "value": "#f0f0f0", "type": "color" },
      "text-primary": { "value": "#1a1a1a", "type": "color" },
      "text-secondary": { "value": "#666666", "type": "color" }
    },
    "fontSize": {
      "body": { "value": 14, "unit": "px" },
      "h1": { "value": 24, "unit": "px" },
      "h2": { "value": 20, "unit": "px" },
      "h3": { "value": 18, "unit": "px" },
      "h4": { "value": 16, "unit": "px" },
      "caption": { "value": 12, "unit": "px" }
    },
    "spacing": {
      "xs": { "value": 4, "unit": "px" },
      "sm": { "value": 8, "unit": "px" },
      "md": { "value": 16, "unit": "px" },
      "lg": { "value": 24, "unit": "px" },
      "xl": { "value": 32, "unit": "px" }
    },
    "borderRadius": {
      "sm": { "value": 4, "unit": "px" },
      "md": { "value": 8, "unit": "px" },
      "lg": { "value": 12, "unit": "px" }
    }
  },
  "components": [],
  "confidence": "high"
}
```

## 不可用时的降级策略

| 情况 | 降级策略 |
|------|---------|
| MCP 不可用 | 尝试 REST API（需 PAT） |
| REST API 返回 403 | 检查 PAT 权限，降级到人工辅助模式 |
| 文件无 Variables | 从节点属性频率统计提取（Path-B 降级） |
| 全部不可用 | 人工辅助模式，用户提供规范值 |