# 修复与提 CR

本 Skill 在 Step 5-6 中使用，用于处理修复代码和提交变更。

## 修复规范

### 修复类型

| 类型 | 示例 | 修复方式 |
|------|------|---------|
| **硬编码 → Token** | `color: #1890ff` → `color: var(--color-brand-default)` | 替换为 CSS Variable |
| **错误值纠正** | `border-radius: 12px` → `border-radius: 8px` | 替换为 Figma 规范值 |
| **补充属性** | 缺少 `box-shadow` | 补充正确的 shadow token |
| **Tailwind 类名** | `className="text-gray-500"` → `className="text-gray-400"` | 替换类名 |

### 修复原则

1. **只改样式层**：CSS 文件、`.module.css`、Tailwind 类名、内联 `style` 对象。不改 JS 业务逻辑。
2. **优先用 Token**：如果项目已使用 Token 系统，优先替换为 `var(--xxx)`，而不是硬编码值。
3. **每改必验**：每次修改后用 Read 验证文件内容正确。
4. **逐项确认**：每处修改前询问用户确认。

### 修复示例

```diff
/* src/components/Card/index.module.css */
.card {
-  border-radius: 12px;
+  border-radius: var(--radius-md, 8px);
  background: var(--color-bg-base);
}
```

```diff
/* src/pages/Home/index.tsx */
- <div className="p-6">  {/* Tailwind: 24px */}
+ <div className="p-4">  {/* Tailwind: 16px — 匹配 Figma spacing-md */}
```

## 提 CR 流程

### 步骤 1：Stage 修改

```bash
git add <修改的文件路径>
```

### 步骤 2：Commit

使用 `icode-git-commit` Skill 生成符合规范的 commit message。

Commit message 模板：
```
fix(design-review): 根据设计走查修正样式值与 Figma 规范对齐

- Card 组件圆角 12px → 8px（匹配 --radius-md）
- Button 主色 #1890ff → #1677ff（匹配 --color-brand-default）
- DetailPage 内容间距 24px → 16px（匹配 --spacing-md）

关联卡片：<iCafe card id>
```

### 步骤 3：Push

```bash
git push origin <branch-name>
```

### 步骤 4：发起 CR

使用 `icode-review-assistant` Skill 发起代码评审。

CR 标题建议：
```
[Design Review] 样式走查修正 - 与 Figma 规范对齐
```

CR 描述中包含走查报告的摘要链接或关键信息。

### 步骤 5：提供 CR 链接

将生成的 CR 链接给设计师和相关研发。

## 截图同步（不提交 CR 时）

当用户选择不提交 CR 时：

1. 告知用户当前修改了哪些文件
2. 建议用户在浏览器中刷新验证效果
3. 如果用户需要同步给研发，提供修改摘要文案（可直接粘贴到如流群）：

```
【设计走查修改摘要】
项目：xxx
修改文件：3 个
1. Card 圆角 12px → 8px（src/components/Card/index.module.css:42）
2. 按钮主色 #1890ff → #1677ff（src/components/Button/index.module.css:15）
3. 详情页间距 24px → 20px（src/pages/DetailPage/index.module.css:78）
```

## 常见问题

### 修改被研发的代码风格工具覆盖

项目可能配置了 Prettier / Stylelint 自动格式化。修复后运行一次：

```bash
npm run lint:style -- --fix
```

确保修改通过样式检查。

### 修改后编译报错

Token 名称可能不对（大小写、拼写）。立即回退修改，从 `token.json` 或 `theme.css` 中确认正确的 Token 名。

### 多个设计师同时走查

每人从 `main` 拉出自己的走查分支，互不干扰。合入时 CR 各自独立。