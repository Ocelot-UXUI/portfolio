# Token 自动检测

本 Skill 在 Step 1c 中使用，用于自动检测项目的 Design Token 系统。

## 检测流程

按优先级依次检查：

### 1. 标准 Token 文件

使用 Glob 搜索以下模式：

```
**/token.json
**/tokens.json
**/design-tokens.json
**/tokens.config.*
**/style-dictionary.config.*
```

找到后读取并解析 JSON，提取 `color`、`spacing`、`fontSize`、`borderRadius`、`shadow` 等类别。

### 2. CSS Variables（:root / theme.css）

使用 Grep 在以下文件中搜索 `--*` 变量定义：

```
**/*.css
**/*.less
**/*.scss
```

搜索模式：`--[\w-]+:\s*[^;]+`（匹配 CSS Variable 定义）

提取后按语义自动归类：

| 变量名模式 | 归类 |
|-----------|------|
| `--color-*`、`--clr-*` | 颜色 |
| `--font-size-*`、`--text-*`、`--fs-*` | 字号 |
| `--spacing-*`、`--space-*`、`--gap-*`、`--pad-*` | 间距 |
| `--radius-*`、`--rounded-*`、`--br-*` | 圆角 |
| `--shadow-*`、`--shd-*` | 阴影 |

### 3. Tailwind Config

搜索 `tailwind.config.*`、`tailwind.config.*.{js,ts,mjs}`。

解析 `theme.extend` 和 `theme` 下的：
- `colors`
- `spacing`
- `fontSize`
- `borderRadius`
- `boxShadow`
- `fontFamily`

### 4. Less/SCSS 变量

搜索 `**/*.less` 中的 `@变量名` 和 `**/*.scss` 中的 `$变量名`。

搜索模式：
- Less: `@[\w-]+:\s*[^;]+`
- SCSS: `\$[\w-]+:\s*[^;]+`

### 5. 硬编码值检测（无 Token 系统时的兜底）

若以上均未命中，判定为**无 Token 系统**。

此时扫描代码中高频出现的样式值（出现 ≥ 3 次），作为"候选 Token"输出给用户确认：

```
候选颜色 Token：
  #1890ff 出现 23 次 → 建议命名为 --color-primary
  #f0f2f5 出现 15 次 → 建议命名为 --color-bg-page

候选字号 Token：
  14px 出现 31 次 → 建议命名为 --font-size-body
  16px 出现 12 次 → 建议命名为 --font-size-h4
```

## 输出格式

无论哪种方式检测到 Token，最终输出统一结构：

```json
{
  "hasTokens": true,
  "tokenType": "css-variables",  // "css-variables" | "tailwind" | "json" | "less" | "scss" | "none"
  "categories": ["color", "spacing", "fontSize", "borderRadius", "shadow"],
  "count": {
    "color": 12,
    "spacing": 8,
    "fontSize": 6,
    "borderRadius": 4,
    "shadow": 3
  },
  "files": ["src/styles/theme.css", "src/styles/tokens.css"],
  "samples": {
    "color": [
      {"token": "--color-brand-default", "value": "#1677ff"},
      {"token": "--color-bg-base", "value": "#ffffff"}
    ]
  },
  "hardcodedCount": 15
}
```

## 边界情况

- **混合 Token 系统**：同时存在 CSS Variables 和 Tailwind config → 以 CSS Variables 为 SSOT，Tailwind 视为派生层
- **Token 定义在远程包中**：如 `@company/design-tokens` → 读取 `node_modules` 中对应包的 Token 文件
- **无 Token 系统**：不强行引入 Token，以"注释 + 候选值"方式输出