# 代码扫描策略

本 Skill 在 Step 3 中使用，用于扫描代码中的实际样式值。

## 通用约束

- **禁止**全量读取超过 500 行的样式文件
- 先用 `wc -l` 检查文件长度，大文件用 Grep 精准定位
- 扫描结果按类别和严重程度组织

## 扫描类别与搜索模式

### 1. 颜色

```
# Grep 搜索模式
rg '#[0-9a-fA-F]{6}\b' --type-add 'web:*.{css,less,scss,tsx,jsx,js,ts}' -t web
rg '#[0-9a-fA-F]{3}\b' -t web
rg 'rgb\(\d+,\s*\d+,\s*\d+\)' -t web
rg 'rgba\(\d+,\s*\d+,\s*\d+,\s*[\d.]+\)' -t web
rg '(?:^|\s)(red|blue|green|white|black|gray|transparent|currentColor)\b' -t web
```

排除注释中的颜色值（通常以 `//` 或 `/*` 开头）。

### 2. 字号

```
rg 'font-size:\s*[\d.]+px' --type-add 'web:*.{css,less,scss}' -t web
rg 'font-size:\s*[\d.]+rem' -t web
```

Tailwind 字号类名（`text-sm`、`text-base`、`text-lg`、`text-xl`、`text-2xl` 等）会映射到具体 px 值。

### 3. 间距（padding / margin / gap）

```
rg '(?:padding|margin|gap):\s*[\d.]+px' --type-add 'web:*.{css,less,scss}' -t web
rg '(?:padding|margin):\s*[\d.]+px\s+[\d.]+px' -t web  # 多值
```

### 4. 圆角

```
rg 'border-radius:\s*[\d.]+px' --type-add 'web:*.{css,less,scss}' -t web
rg 'border-radius:\s*[\d.]+%' -t web
rg 'rounded(?:-(?:sm|md|lg|xl|2xl|3xl|full))?\b' -t web  # Tailwind
```

### 5. 阴影

```
rg 'box-shadow:' --type-add 'web:*.{css,less,scss}' -t web
rg 'shadow(?:-(?:sm|md|lg|xl|2xl|inner|none))?\b' -t web  # Tailwind
```

### 6. 边框

```
rg 'border:\s*[\d.]+px\s+solid' --type-add 'web:*.{css,less,scss}' -t web
rg 'border-width:\s*[\d.]+px' -t web
rg 'border-color:\s*#' -t web
```

## 扫描范围

按优先级从高到低：

1. **样式文件**：`*.css`、`*.module.css`、`*.less`、`*.scss`（在 `src/` 或 `components/` 下）
2. **组件文件**：`*.tsx`、`*.jsx` 中的内联样式 `style={{ }}` 和 Tailwind 类名 `className="..."`
3. **Tailwind 配置**：`tailwind.config.*` 中的 `theme.extend` 值
4. **全局样式**：`index.css`、`global.css`、`app.css` 等

## Tailwind 类名解析

将 Tailwind 类名映射为具体 CSS 值：

| 类名 | 对应值 | 说明 |
|------|--------|------|
| `text-sm` | font-size: 14px | 需确认 Tailwind config 是否覆盖 |
| `text-base` | font-size: 16px | 同上 |
| `p-4` | padding: 16px | Tailwind 默认 1rem=16px |
| `rounded-lg` | border-radius: 8px | 同上 |
| `shadow-md` | box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1) | 同上 |

如果项目自定义了 Tailwind config，优先使用自定义配置中的值。

## 输出格式

扫描结果输出为结构化数据：

```json
{
  "filesScanned": 24,
  "totalValues": {
    "color": 45,
    "fontSize": 18,
    "spacing": 67,
    "borderRadius": 12,
    "shadow": 8,
    "border": 15
  },
  "byCategory": {
    "color": [
      {"value": "#1677ff", "frequency": 23, "locations": ["src/components/Button/index.tsx:12"]},
      {"value": "#ffffff", "frequency": 56, "locations": ["src/layouts/Page/index.module.css:5"]}
    ]
  },
  "usingTokens": {
    "color": 30,
    "fontSize": 14,
    "spacing": 50,
    "borderRadius": 9,
    "shadow": 6
  },
  "hardcoded": {
    "color": 15,
    "fontSize": 4,
    "spacing": 17,
    "borderRadius": 3,
    "shadow": 2
  }
}
```

## 边界情况处理

- **动态样式**：通过 JS 计算的样式（如 `style={{ color: isActive ? '#1890ff' : '#666' }}`）→ 提取两个分支的值
- **CSS-in-JS**：`styled-components`、`emotion` → 提取模板字符串中的 CSS 值
- **外部 CDN 样式**：无法扫描，在报告中标注
- **CSS Modules 的 composes**: 追踪到被 compose 的类定义
- **第三方组件样式**：`node_modules` 中的组件样式默认排除，除非用户指定要扫描