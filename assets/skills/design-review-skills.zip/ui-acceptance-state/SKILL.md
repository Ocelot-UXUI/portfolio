---
name: ui-acceptance-state
description: 状态完整性验收 Skill。用于单独检查 default、loading、empty、error、success、disabled、权限不足、数据为空、异常等页面和组件状态是否覆盖完整。用户只要说只查状态、状态覆盖、空态/加载态/错误态/成功态、异常状态、状态流转是否齐全，就应触发。只做状态覆盖判断，不替代视觉、交互或源码验收。
---

# 状态完整性验收

你负责检查页面和组件状态是否齐全、可触发、可复验。

## 你要做什么

- 列出本次范围内应覆盖的状态
- 检查 default / loading / empty / error / success / disabled 等状态
- 记录状态触发条件、页面表现和缺失项
- 使用 `agent-browser` 优先采集运行态证据

## 判断重点

- 默认态是否正确
- 加载态是否存在且不遮挡关键操作
- 空态是否有明确文案和下一步
- 错误态是否可理解、可恢复
- 成功态是否有反馈
- 权限不足 / 数据异常是否有兜底

## 设计原则

- 状态必须覆盖完整，不能只验主流程
- 缺失状态要标风险
- 状态流转要可追踪、可复验
- 无法触发目标状态时输出降级，不脑补结论

## 输出格式

```markdown
# 状态完整性验收报告

## 一、结论
- 范围：
- runtime_channel：
- 已覆盖状态：
- 缺失状态：

## 二、状态问题
- id：
- severity：
- state：
- trigger_condition：
- runtime_evidence：
- actual：
- expected：
- recommendation：

## 三、阻塞 / 降级
```
