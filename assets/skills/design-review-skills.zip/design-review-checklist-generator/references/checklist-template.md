# 用例模板与示例

## 用例模板 Schema

```
字段         | 类型    | 必填 | 说明
-------------|---------|------|----------------------
ID           | String  | ✅   | {前缀}-{分类}{序号}
Module       | String  | ✅   | 所属功能模块
Phase        | String  | ✅   | 一期/一点五期/二期/三期/全量
Dimension    | String  | ✅   | 功能/IA/交互/视觉/多端/动效/文案
Type         | String  | ✅   | UI / Interaction / Function / Copy
Tool         | String  | ✅   | UI Comparison / Browser Use / Both
Description  | String  | ✅   | 检查内容（可验证的陈述句，不含模糊词）
Criteria     | String  | ✅   | 验证标准或具体操作步骤
Priority     | String  | ✅   | P0 / P1 / P2
Source       | String  | ✅   | 依据来源（PRD §章节 / Figma Frame 名称）
```

### ID 命名规则

```
{前缀}-{分类字母}{两位数序号}

前缀 = 模块英文缩写（3-4 大写字母）
分类字母 = F(功能) / I(交互) / V(视觉) / C(文案)
序号 = 01-99
```

### 模块前缀表

| 模块 | 前缀 | 示例 |
|------|------|------|
| 工区入口与列表 | ENT | ENT-F01, ENT-V03 |
| 工区创建 | CRT | CRT-F02, CRT-I01 |
| 工区基础管理 | MGT | MGT-F01, MGT-C01 |
| 工区设置页 | SET | SET-F01, SET-V02 |
| 文件管理 | FIL | FIL-F01, FIL-I02 |
| 文件同步 | SYN | SYN-F01 |
| 自动化任务 | TSK | TSK-F01, TSK-F02 |
| 成员管理 | MEM | MEM-F01, MEM-I02 |
| 如流端 | INF | INF-F01 |
| 全局 UI | GLO | GLO-V01, GLO-C01 |

---

## 各维度的用例示例

### 示例 1：功能完整性（Function）

```
ID          | CRT-F02
Module      | 工区创建
Phase       | 一期
Dimension   | 功能
Type        | Function
Tool        | Browser Use
Description | 工区名称为空时提示"工区名称不能为空"，不创建工区
Criteria    | 1. 清空名称输入框 → 2. 按 Enter 或失焦 → 3. 验证输入框标红
                → 4. 验证提示文案"工区名称不能为空" → 5. 验证工区未被创建
Priority    | P0
Source      | PRD §4.1 创建工区-名称校验
```

### 示例 2：交互流程闭环（Interaction）

```
ID          | ENT-I03
Module      | 工区入口
Phase       | 一期
Dimension   | 交互
Type        | Interaction
Tool        | Browser Use
Description | 点击展开/收起图标仅触发列表展开/收起，不触发新建对话
Criteria    | 1. Hover 卡片（验证出现展开图标）→ 2. 点击展开图标
                → 3. 验证仅展开对话列表，未触发新建对话（没有跳转/新建输入框）
                → 4. 点击卡片主体（非图标区域）→ 5. 验证触发新建对话
Priority    | P1
Source      | Figma 交互稿「工区详情」- 卡片展开收起
```

### 示例 3：视觉还原度（Visual）

```
ID          | ENT-V01
Module      | 工区列表
Phase       | 一期
Dimension   | 视觉
Type        | UI
Tool        | UI Comparison
Description | 工区卡片样式与设计稿一致：卡片圆角、阴影、字体字号、图标尺寸
Criteria    | 对比 Figma 视觉稿（Frame 2147228344）：
                - border-radius: 8px
                - box-shadow: 0 2px 8px rgba(0,0,0,0.08)
                - 标题字号: 14px Medium
                - 类型图标尺寸: 20x20
Priority    | P1
Source      | Figma 视觉稿 Frame 2147228344
```

### 示例 4：文案与内容（Copy）

```
ID          | MGT-C01
Module      | 工区删除
Phase       | 一期
Dimension   | 文案
Type        | Copy
Tool        | UI Comparison
Description | 删除个人工区的确认弹窗文案与 PRD 一致
Criteria    | 弹窗标题："确认删除该专属工区？"
                弹窗内容："{工区名}删除后将同时删除云端目录与客户端本地同步目录，
                绑定该工区的定时任务也会一并删除。删除后不可恢复。"
                按钮：「取消」「删除」
Priority    | P0
Source      | PRD §4.1 工区删除
```

---

## 合成规则速查

### PRD → 用例映射规则

| PRD 内容类型 | → 产出用例类型 | 数量建议 |
|-------------|---------------|---------|
| 功能需求点（列表中的每一条） | Function（P0：正向 / P1：边界） | 1 P0 + 1 P1 |
| 表格类需求（需求详情表格每行） | Function + Interaction + Visual | 每行至少 3 条（各维度 1 条） |
| 用户故事 | Function（P0 正向流程） | 每则故事 1 条 P0 |
| 校验规则 | Function | 每条规则 1 条 P0 |
| 边界条件 / 不做什么 | Function（否定式验证） | 每条 1 条 P1 |
| 二次确认场景 | Function | 每个场景 1 条 P0 |
| 配额限制 | Function | 1 P1（达上限）+ 1 P1（边界） |
| 多端差异描述 | Cross-platform | 每个端差异 1 条 |
| 异步/定时行为 | Function | 1 P0（成功）+ 1 P1（失败） |

### Figma → 用例映射规则

| Figma 内容 | → 用例类型 | 数量建议 |
|-----------|-----------|---------|
| 交互稿中的 TEXT 说明 | Interaction | 每段说明 1-2 条 |
| FRAME 名称（不同页面） | Visual | 每帧 1 条 |
| 同一组件的多个状态帧 | Visual + Interaction | 每个状态 1 条 |
| 交互流程连接线/路径 | Interaction | 每条路径 1 条 |
| Design Token | Visual UI Comparison | 5 大类（颜色/字体/间距/圆角/阴影）各 1 条 |

### 工具选择规则

| 用例类型 | 推荐工具 | 说明 |
|---------|---------|------|
| UI 视觉对比 | UI Comparison | AI 模型做像素级/布局级对比 |
| 功能校验 | Browser Use | 模拟用户操作验证功能逻辑 |
| 交互流程 | Browser Use | 模拟用户操作路径 |
| 异常/边界 | Browser Use | 构造特定条件触发异常 |
| 文案内容 | Both | UI Comparison 截图+人工复核 |
| 动效 | UI Comparison | 视频录制或逐帧对比 |