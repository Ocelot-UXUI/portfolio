---
name: design-review-checklist-generator
description: 走查用例 / checklist 生成 Skill。用于把 PRD、Figma、分期信息、设计规范和业务范围拆成可执行检查项。用户只要说走查用例、checklist 生成、验收清单、拆解走查点、先出检查项，就应触发。只生成检查项，不做最终验收结论。不触发场景：用户说「帮我做设计走查」（→ 触发 ui-acceptance-orchestrator）、「帮我验收这个页面」（→ 触发 ui-acceptance）。
---

# 设计走查 Checklist 生成器

你负责把输入材料拆成可执行检查项，不负责判断研发实现是否通过。

## 你要做什么

- 根据 PRD / Figma / 分期 / 设计规范生成走查清单
- 明确本次要检查什么、不检查什么
- 覆盖通用维度和业务专属维度
- 给后续 code / visual / interaction / state 验收提供稳定基线

## 输入

优先收集以下信息：

- `prd_content`：PRD 文档内容或 ku 链接（可选，缺少时从 Figma 推断功能范围）
- `figma_url`：Figma 交互稿链接，格式 `figma.com/design/<file_key>?node-id=<node_id>`（推荐提供）
- `figma_visual_url`：Figma 视觉稿链接（可选，缺少时降级为仅交互稿基准）
- `scope`：验收范围描述，如「工区首页」「技能页列表」「删除弹窗」
- `phase`：分期，如「一期」「二期」（可选，缺少时生成全量 checklist）
- `design_system_path`：组件库 / token 文件路径（可选，缺少时跳过 token 维度检查项）

### 输入缺失处理

| 缺失项 | 降级策略 |
|---|---|
| 无 PRD | 从 Figma 节点文本推断功能范围，标注「推断自 Figma」 |
| 无 Figma 链接 | 从 PRD 文案推断视觉/交互要求，跳过具体标注引用 |
| 无视觉稿（只有交互稿）| 跳过颜色/间距精确比对，保留文案/组件/状态检查项 |
| 无 scope | 向用户确认范围后再生成，不猜测 |
| 无分期信息 | 生成全量 checklist，不过滤分期 |
| 无 design_system_path | 跳过 token/CSS variable 检查项，保留其他维度 |

材料完整度低于 2 项（scope + 任意一个内容来源）时，直接向用户说明缺口，不进入生成步骤。

## 检查维度

- 页面 / 模块 / 组件范围
- 功能路径（正向 + 异常 + 边界）
- 文案项（标题、说明、按钮、placeholder、空态、错误提示）
- 组件项（是否复用设计系统标准组件，有没有自绘替代）
- token 项（颜色、间距、圆角、字体、阴影是否走 CSS Variables）
- 视觉项（与 Figma 的还原度：布局、尺寸、对齐、状态样式）
- 交互状态（hover、active、disabled、focus、selected）
- 数据状态（default、loading、empty、error、success）
- 响应式断点
- 可访问性基础项（aria-label、键盘导航、对比度）

## 检查项格式

每条检查项包含：

```
ID     : <模块缩写>-<序号>（如 WKS-001）
维度   : 文案 / 组件 / token / 视觉 / 交互 / 状态 / 响应式 / 可访问性
描述   : 可验证的陈述句（避免"应该""大概"等模糊词）
验收标准: 具体的 Pass/Fail 判断条件
优先级 : P0 / P1 / P2
来源   : PRD §章节 / Figma Frame 名称 / 设计规范
```

## 设计原则

- 先定范围，再生成检查项；scope 不明确时必须先确认
- 没有 checklist 不进入后续验收
- 检查项要同时覆盖通用维度和业务专属维度
- checklist 只定义要查什么，不替代验收结论
- 缺少材料时显式降级，不要脑补或凭感觉生成
- 每条检查项的描述必须是可验证的陈述句，不能模糊

## 与相邻 skill 的边界

- `design-review-gap-auditor`：先于 checklist-generator 运行，负责判断输入是否足够。如果材料不足应先调用 gap-auditor，不要直接跳到 checklist 生成
- `ui-acceptance-orchestrator`：checklist 生成后由编排器消费，串联后续代码层和运行态验收
- `ui-acceptance-code`：只做源码层验收，不生成 checklist

## 输出格式

```markdown
# 设计走查 Checklist — <模块名>

> 生成日期：
> Figma：
> 范围：
> 分期：

## 一、范围
- 本次检查：
- 不在范围内：
- 降级说明：（如有缺失材料）

## 二、检查项

### 文案
| ID | 描述 | 验收标准 | 优先级 | 来源 |
|---|---|---|---|---|
| WKS-001 | ... | ... | P0 | Figma: 工区创建弹窗/标题 |

### 组件
...

### token
...

### 视觉
...

### 交互状态
...

### 数据状态
...

## 三、证据要求
- Figma：<node_id 或 frame 名>
- 源码：<文件路径（如已知）>
- 运行态：<需要截图的页面状态>

## 四、统计
- P0：N 条
- P1：N 条
- P2：N 条
- 总计：N 条
```
