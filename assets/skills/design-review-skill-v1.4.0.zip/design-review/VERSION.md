##版本号
v1.1.0

##更新时间
2026-07-03

##更新内容
- 新增 Intake Gate（评审前硬门禁）：必须在评审前确认 business_context、target_user、review_focus 三个字段
- 新增 intake_confirmed / intake_mode / business_context_source 等 workflow_state 字段追踪门禁状态
- 明确禁止从模块名、页面标题推断业务背景
- 新增 user_skipped / visual_only 两种绕过模式
- 移除旧版 "采集最小业务背景" 的软性规则，替换为硬门禁机制