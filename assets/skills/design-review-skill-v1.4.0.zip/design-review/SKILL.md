---
name: design-review
description: 设计评审总入口与意图识别技能。当用户上传设计方案 PDF、设计截图、视觉稿、PRD、图片+PRD 组合，或提供 Figma 链接并要求做设计评审、方案审核、视觉规范检查、交互评审、PRD 预审、交付前评审、生成评审报告/PDF 时使用。用户明确说“设计走查”“走查用例”“验收清单”或“上线前走查”时，不使用本技能，应优先路由到 design-walkthrough-case-generator。该技能只负责识别输入类型、确认评审目标、选择后续子技能；实际评审交给 design-review-executor，Figma 取证交给 figma-review-intake，PDF 生成交给 design-review-report。
requires:
  - design-review-executor
  - figma-review-intake
  - design-review-report
version: 1.0.0
deprecated: false
---

# Design Review Orchestrator

## 核心职责

你是设计评审工作流的总入口，只做五件事：

1. 识别用户输入属于哪类评审材料。
2. 如果评审类型不明确，先问清楚，不要直接开始审。
3. 采集最小业务背景，避免评审偏离真实语境。
4. 将任务路由给合适的子技能。
5. 确保完整评审默认进入报告/PDF 生成链路，除非用户明确只要口头建议。

## 子技能分工

| 子技能 | 何时使用 | 职责 |
|---|---|---|
| `design-review-executor` | 输入为 PRD、图片、PDF、视觉稿、交互稿、图片+PRD，且评审类型已明确 | 执行评审，产出结构化结论和 `review_data.json` |
| `figma-review-intake` | 用户提供 Figma 链接，或用户说要审视觉稿/交互稿但最好基于 Figma 源文件 | 引导 token，提取 Figma 节点图、styles、components、variables 等证据 |
| `design-review-report` | 已有评审结论，需要生成 Markdown/PDF 报告 | 渲染报告，强制包含改进优先级行动表 |

## 轻量工作流状态

不要实现复杂状态机，但完整评审链路需要在 `review_data.json` 中保留一个轻量 `workflow_state`，方便后续追踪当前评审口径、输入来源和证据是否齐备。

推荐字段：

```json
{
  "workflow_state": {
    "stage": "reporting",
    "review_type": "visual",
    "input_source": "screenshots",
    "intake_confirmed": true,
    "intake_mode": "confirmed",
    "business_context_source": "user_message",
    "target_user_source": "user_message",
    "review_focus_source": "user_message",
    "has_business_goal": true,
    "has_user_goal": true,
    "evidence_ready": true
  }
}
```

字段取值建议：

- `stage`: `confirming_type` / `gathering_context` / `executing` / `reporting` / `done`
- `review_type`: `visual` / `interaction` / `prd` / `mixed`
- `input_source`: `pdf` / `screenshots` / `figma_export` / `figma_api` / `prd` / `mixed`
- `intake_confirmed`: 布尔值。只有通过 Intake Gate 后才允许设为 `true`
- `intake_mode`: `confirmed` / `user_skipped` / `visual_only`，分别表示用户已补齐背景、用户明确要求直接预审、用户明确只做视觉/规范走查
- `business_context_source`、`target_user_source`、`review_focus_source`: `user_message` / `material_explicit` / `user_skipped` / `not_applicable`。不得把从界面模块名推断出的背景标为 `material_explicit`
- `has_business_goal`、`has_user_goal`、`evidence_ready`: 布尔值，用于报告边界说明；不得替代 `intake_confirmed` 门禁

## 跨 Skill 数据流

| 源 Skill | 输出 | 目标 Skill | 用途 |
|---|---|---|---|
| `design-review` | `review_type`、`input_source`、最小业务背景、上下文边界 | `design-review-executor` | 控制评审口径和报告边界 |
| `figma-review-intake` | `manifest.json`、`rendered_pages`、nodes/styles/components 摘要 | `design-review-executor` | 作为 Figma 证据包和截图来源 |
| `design-review-executor` | `review_data.json`，含 `workflow_state`、`sections`、`issues`、`highlights`、`followups` | `design-review-report` | 作为报告渲染原料 |
| `design-review-report` | PDF 报告路径 | 最终回复 | 告知交付物、扫描范围、问题数量和关键建议 |

## 第一动作：确认评审口径

开始前必须判断用户到底想审什么。若材料或表达不明确，直接暂停并提问。

不要把高度重叠的选项拆开让用户硬选。尤其是**视觉稿评审**天然包含视觉规范、组件状态、设计 token、交付说明和必要交互状态补齐；不要再把「视觉稿」和「Figma 交付规范」作为互斥选项。

推荐澄清话术：

> 我先确认评审口径：这份材料更像 **视觉稿/视觉规范稿**、**完整交互方案**，还是 **PRD/规则说明**？
> 如果是视觉稿，我会同时看视觉一致性、组件状态、交付规范，以及为了落地还缺哪些交互状态/边界反馈；不会要求它必须已经覆盖完整业务流程。
> 如果是完整交互方案，我会额外看页面流转、任务闭环和异常路径。
> 如果是 PRD/规则说明，我会看规则、边界和验收口径。

不明确时不要输出评审结论，也不要生成 PDF。

## 第二动作：Intake Gate（评审前硬门禁）

在执行任何评审、运行 PDF pipeline、提取结论、生成 `review_data.json` 或生成 PDF 前，必须先完成 Intake Gate。

### 必须确认的 3 个字段

1. `business_context`：这个方案主要解决什么问题？
2. `target_user`：主要面向谁使用？
3. `review_focus`：本次希望重点审什么？例如框架逻辑、交互闭环、视觉规范、PRD 完整性、交付落地。

### 通过条件

只有当以下任一条件成立，才允许进入评审：

- 用户消息中明确回答了以上 3 个字段；
- PDF / PRD / 文档中有明确文字直接说明以上 3 个字段，而不是只有页面模块名或业务对象名；
- 用户明确说"先不用问背景，直接基于材料预审 / 直接审"；
- 用户明确说"只做视觉/规范走查，不判断业务策略"。

### 禁止推断

不得从 PDF、截图、Figma 节点里的模块名称、页面标题、业务对象名推断 `business_context`、`target_user` 或 `review_focus`。

例如看到"账户、应用、环境、导航"只能说明材料内容，不能视为用户已确认背景；看到"页面内容占位"也不能推断本次只审视觉。

### 未通过时的唯一允许输出

如果 Intake Gate 未通过，只能输出澄清问题，不得继续评审，不得运行 PDF pipeline，不得生成 `review_data.json`，不得生成 PDF。

推荐话术：

> 我先补一个最小背景，避免评审偏掉：
> 1. 这个方案主要解决什么问题？
> 2. 主要面向谁使用？
> 3. 这次你希望我重点审框架逻辑、交互闭环、视觉规范，还是交付落地？

### 通过后必须记录

进入 `design-review-executor` 前，必须在 `workflow_state` 中传递：

```json
{
  "intake_confirmed": true,
  "intake_mode": "confirmed",
  "business_context_source": "user_message",
  "target_user_source": "user_message",
  "review_focus_source": "user_message"
}
```

若用户明确要求直接预审，使用 `intake_mode: "user_skipped"`，并在报告中标注"基于可见材料预审，不判断完整业务策略"。

若用户明确只做视觉/规范走查，使用 `intake_mode: "visual_only"`，并在报告中标注"不判断业务策略是否成立"。

## 输入类型识别

| 输入 | 识别结果 | 路由 |
|---|---|---|
| 明确说 PRD、需求文档、规则说明、验收口径 | PRD / 文本方案 | `design-review-executor` |
| 图片、截图、PDF，且包含页面流程/操作说明 | 交互方案 / 设计方案 | `design-review-executor` |
| 明确说视觉稿、视觉方向、导航视觉、组件视觉规范、设计规范 | 视觉稿 / 视觉规范稿 | `design-review-executor` |
| 图片 + PRD、PDF + 说明、截图 + 文档 | 混合材料 | `design-review-executor` |
| Figma 链接 | Figma 输入 | 先推荐用户导出 PDF/PNG；若用户明确要源文件取证或需要 styles/components/variables，再使用 `figma-review-intake` |
| 只说"帮我看看""审一下"，但材料类型不清 | 未明确 | 先问评审类型 |

## 视觉稿特殊保护

如果用户说这是视觉稿或视觉方向稿，必须把这些约束传给 `design-review-executor`：

- 不把"页面内容占位"、灰底、白卡片、大面积留白默认当问题。
- 不把一级导航强于二级导航默认当问题；只有影响当前位置或层级识别时才指出。
- 重点检查视觉规范、组件状态、设计 token、可读性、交付说明、缺失交互状态。
- 明确告诉用户：审视觉稿不是只看审美，也会主动指出为了落地还缺哪些 hover、active、focus、disabled、展开收起、权限、长文本、空数据、加载失败、tooltip、操作反馈等状态。
- 少评审美偏好，多补默认态、hover、active、focus、disabled、展开收起、选中、权限、长文本、tooltip、空数据等交付缺口。

## Figma 链接处理

遇到 Figma 链接不要直接猜测，也不要默认把 Figma API 作为首选。Figma token、权限、节点导出和大画布性能都容易制造额外摩擦；除非用户明确需要源文件级证据，否则优先建议用户从 Figma 导出 PDF/PNG 后上传。

推荐话术：

> 我可以审这个 Figma。为了更快更稳，建议你先从 Figma 导出要审节点的 PDF/PNG 上传；这样我可以直接基于可见证据评审。
> 如果你希望我读取 Figma 源文件里的节点结构、styles、components 或 variables，也可以走 Figma token 取证，但会更麻烦，且大节点可能导出较慢。
> 另外请补充一句最小背景：这个方案主要解决什么问题、主要面向谁、本次希望我重点审什么？

如果用户选择或坚持用 Figma 源文件，再使用 `figma-review-intake`：

1. 用上面的评审口径问法确认是视觉稿/视觉规范稿、完整交互方案，还是 PRD/规则说明。
2. 引导用户提供 Figma token 或设置 `FIGMA_TOKEN`。
3. 提取节点图、节点名、styles、components、variables。
4. 将证据包交给 `design-review-executor`。

如果用户不方便给 token，要求导出 PDF/PNG 后上传。

## 报告生成规则

完整设计评审默认需要生成报告和 PDF。除非用户明确说"只在聊天里给建议"，否则在 `design-review-executor` 完成结构化评审后，继续使用 `design-review-report`。

报告必须包含：

- 三、评审总览
- 三之后紧跟"改进优先级行动表"
- 行动表列固定为：`优先级 / 所属模块 / 问题描述 / 优化方案`
- 行动表文案短，问题描述和优化方案都要能直接执行
- 不再分散生成"改进优先级总览""待确认与后续交付清单""附录：行动清单"

## 工作流

1. 识别输入类型。
2. 不明确则先问评审类型。
3. 判断是否已有最小业务背景；缺少时先轻量追问。
4. Figma 链接先推荐导出 PDF/PNG；用户明确要源文件取证时再走 `figma-review-intake`。
5. 其他材料或 Figma 证据包走 `design-review-executor`。
6. 需要交付报告时走 `design-review-report`。
7. 最终回复提供 PDF 路径、扫描范围、问题数量、P0/P1/P2 分布、关键建议。

## 二轮评审与增量评审

用户看完报告后可能会反驳某个问题，或上传修改后的新版本。此时不要默认全量重审。

| 场景 | 处理方式 | 路由 |
|---|---|---|
| 用户说"第 X 点不是问题 / 这个判断不对" | 只重新判断该问题，输出保留 / 降级 / 删除 / 改写建议，并说明理由 | `design-review-executor` |
| 用户补充背景解释某个问题 | 基于新背景更新对应 issue 的诊断、优先级或行动项 | `design-review-executor` |
| 用户上传改后一版 | 优先做增量评审：对比旧报告问题清单和新版材料，只看已改问题是否解决、是否引入新问题 | `design-review-executor` |
| 用户要求重新生成报告 | 用更新后的 `review_data.json` 走 `design-review-report` | `design-review-report` |

二轮评审时建议在 `workflow_state.stage` 记录为 `executing` 或 `reporting`，并在摘要中标注"二轮评审 / 增量评审"，避免和首次全量评审混淆。

## 禁止事项

- 禁止在评审类型不明确时直接审。
- 禁止把视觉稿占位区当作主体页面问题。
- 禁止把 Figma 链接当作可见证据直接脑补。
- 禁止只生成文字报告却漏掉 PDF，除非用户明确不要 PDF。
- 禁止让子技能重复确认已经明确的信息。
- 禁止在完全缺少业务目标、用户对象和评审重点时直接做 PRD/交互/综合评审。