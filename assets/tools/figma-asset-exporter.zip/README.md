# 原型素材导出器

一个不依赖 AI 的本地 Figma 素材导出插件，用于把设计稿里的原始图片和完整图标提取出来，辅助后续网页原型搭建。

## 当前规则

- 有 `IMAGE` fill 的图层：按图片内容去重，导出原始图片并记录所有出现位置
- 有矢量内容、尺寸不超过 160px 的图标组件 / 实例：整体导出 SVG
- 高置信度素材默认勾选；结构不明确的候选项进入“待确认”且默认不勾选
- 没有可见填充或描边的空图形会在扫描时过滤；被 Figma 判定为空的特殊节点会在导出时自动跳过
- 一次最多导出 500 个素材，避免 Figma 和插件 UI 内存过载
- 文件名附带节点 ID，避免同名图层在 ZIP 中互相覆盖
- 失败项写入 `export-errors.json`，素材位置写入 `asset-manifest.json`
- 不导出完整 Frame，不修改 Figma 文件，也不把图标组件拆成一条条 Vector 路径

## 安装

1. 下载或打开此目录。
2. 在 Figma Desktop 中打开 `Resources → Plugins → Development → Import plugin from manifest…`。
3. 选择本目录的 `manifest.json`。
4. 选中一个或多个 Frame，运行 `原型素材导出器`。

## 注意

分类结果可在插件面板中勾选后调整，点击导出后会下载一个 `prototype-assets.zip`。ZIP 包含素材、`asset-manifest.json`，如果有失败还会包含 `export-errors.json`。

## 本地测试

```bash
node --test tests/classifier.test.js
```
