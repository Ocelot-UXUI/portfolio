const MAX_ICON_EDGE = 160;
const MAX_EXPORT_ITEMS = 500;
const ICON_WORDS = /(^|[\s_\-/])(icon|logo|glyph|symbol|arrow|chevron|search|close|menu|back|forward|home|heart|star|bookmark|share|more)([\s_\-/]|$)|图标|徽标|箭头|搜索|关闭|菜单|返回|收藏|分享|更多/i;
const NON_ICON_WORDS = /(^|[\s_\-/])(button|btn|tab|chip|tag|card|cell|item|avatar|badge|nav|header|footer)([\s_\-/]|$)|按钮|标签|卡片|头像|导航|页头|页脚/i;
const GRAPHIC_TYPES = new Set(['VECTOR', 'BOOLEAN_OPERATION', 'STAR', 'POLYGON', 'ELLIPSE', 'LINE', 'RECTANGLE']);
const CONTAINER_TYPES = new Set(['COMPONENT', 'INSTANCE', 'FRAME', 'GROUP']);

function visibleChildren(node) {
  return 'children' in node ? node.children.filter(child => child.visible !== false) : [];
}

function imagePaints(node) {
  if (!('fills' in node) || !Array.isArray(node.fills)) return [];
  return node.fills.filter(paint => paint && paint.visible !== false && paint.type === 'IMAGE' && paint.imageRef);
}

function paintListHasVisiblePaint(paints) {
  if (paints == null) return false;
  if (!Array.isArray(paints)) return true;
  return paints.some(paint => paint && paint.visible !== false && (paint.opacity == null || paint.opacity > 0));
}

function hasRenderableGraphic(node) {
  if (!node || node.visible === false || (typeof node.opacity === 'number' && node.opacity <= 0)) return false;
  if (GRAPHIC_TYPES.has(node.type) && (paintListHasVisiblePaint(node.fills) || paintListHasVisiblePaint(node.strokes))) return true;
  return visibleChildren(node).some(hasRenderableGraphic);
}

function nodePath(node) {
  const names = [];
  let current = node;
  while (current && current.type !== 'DOCUMENT') {
    if (current.name) names.unshift(current.name);
    current = current.parent;
  }
  return names;
}

function nodeMeta(node) {
  let absolute = null;
  if ('absoluteTransform' in node && node.absoluteTransform) {
    absolute = { x: node.absoluteTransform[0][2], y: node.absoluteTransform[1][2] };
  }
  return {
    nodeId: node.id,
    nodeName: node.name,
    nodeType: node.type,
    parentId: node.parent ? node.parent.id : null,
    parentName: node.parent ? node.parent.name : null,
    path: nodePath(node),
    bounds: 'width' in node ? { x: node.x, y: node.y, width: node.width, height: node.height, absolute } : null,
  };
}

function analyzeNode(node, metrics) {
  if (node.visible === false) {
    const empty = { text: 0, images: 0, graphics: 0, nodes: 0 };
    metrics.set(node.id, empty);
    return empty;
  }
  const total = {
    text: node.type === 'TEXT' ? 1 : 0,
    images: imagePaints(node).length,
    graphics: GRAPHIC_TYPES.has(node.type) ? 1 : 0,
    nodes: 1,
  };
  for (const child of visibleChildren(node)) {
    const childMetrics = analyzeNode(child, metrics);
    total.text += childMetrics.text;
    total.images += childMetrics.images;
    total.graphics += childMetrics.graphics;
    total.nodes += childMetrics.nodes;
  }
  metrics.set(node.id, total);
  return total;
}

function candidateFor(node, metrics) {
  const data = metrics.get(node.id);
  if (!data || !('width' in node) || !('height' in node)) return null;
  const edge = Math.max(node.width, node.height);
  if (edge < 4 || edge > MAX_ICON_EDGE || data.graphics === 0 || data.text > 0 || data.images > 0 || !hasRenderableGraphic(node)) return null;
  const positiveName = ICON_WORDS.test(node.name || '');
  const negativeName = NON_ICON_WORDS.test(node.name || '');
  if (negativeName && !positiveName) return null;
  if (positiveName && (CONTAINER_TYPES.has(node.type) || GRAPHIC_TYPES.has(node.type))) {
    return { score: 100, confidence: 'high', reason: '名称与结构都符合图标特征' };
  }
  if (['COMPONENT', 'INSTANCE'].includes(node.type)) {
    return { score: 65, confidence: 'review', reason: '小型纯图形组件，但名称未明确说明是图标' };
  }
  if (['FRAME', 'GROUP'].includes(node.type) && edge <= 64 && data.graphics <= 24 && data.nodes <= 32) {
    return { score: 45, confidence: 'review', reason: '小型纯矢量容器，需要人工确认边界' };
  }
  return null;
}

function chooseIconRoots(node, metrics) {
  const descendants = [];
  for (const child of visibleChildren(node)) descendants.push(...chooseIconRoots(child, metrics));
  const current = candidateFor(node, metrics);
  if (!current) return descendants;
  const bestDescendantScore = descendants.reduce((best, item) => Math.max(best, item.score), -1);
  if (bestDescendantScore > current.score) return descendants;
  return [{
    id: node.id,
    name: node.name || `icon-${node.id.replaceAll(':', '-')}`,
    type: node.type,
    width: node.width,
    height: node.height,
    score: current.score,
    confidence: current.confidence,
    reason: current.reason,
    source: nodeMeta(node),
  }];
}

function collectImages(selection) {
  const byHash = new Map();
  function visit(node) {
    for (const paint of imagePaints(node)) {
      const occurrence = nodeMeta(node);
      if (!byHash.has(paint.imageRef)) {
        byHash.set(paint.imageRef, {
          id: node.id,
          imageRef: paint.imageRef,
          name: node.name || `image-${node.id.replaceAll(':', '-')}`,
          confidence: 'high',
          reason: 'Figma 原始图片填充',
          occurrences: [],
        });
      }
      byHash.get(paint.imageRef).occurrences.push(occurrence);
    }
    for (const child of visibleChildren(node)) visit(child);
  }
  selection.forEach(visit);
  return [...byHash.values()];
}

function classifySelection(selection) {
  const metrics = new Map();
  selection.forEach(root => analyzeNode(root, metrics));
  const iconMap = new Map();
  for (const root of selection) {
    for (const icon of chooseIconRoots(root, metrics)) iconMap.set(icon.id, icon);
  }
  return {
    selection: selection.map(node => ({ id: node.id, name: node.name, type: node.type })),
    images: collectImages(selection),
    icons: [...iconMap.values()].sort((a, b) => b.score - a.score || a.name.localeCompare(b.name)),
  };
}

function safeBaseName(name) {
  return String(name || 'asset').replace(/[^\w\-\u4e00-\u9fff]+/g, '-').replace(/^-|-$/g, '') || 'asset';
}

function uniqueFilename(item, extension) {
  const identity = item.kind === 'image' ? item.imageRef : item.id;
  const suffix = String(identity || item.imageRef || item.id || 'asset').replace(/[^a-zA-Z0-9]+/g, '-').replace(/^-|-$/g, '').slice(-28);
  return `${safeBaseName(item.name)}--${suffix}.${extension}`;
}

function detectImageFormat(bytes) {
  if (bytes[0] === 0xff && bytes[1] === 0xd8 && bytes[2] === 0xff) return { ext: 'jpg', mime: 'image/jpeg' };
  if (bytes[0] === 0x89 && bytes[1] === 0x50 && bytes[2] === 0x4e && bytes[3] === 0x47) return { ext: 'png', mime: 'image/png' };
  if (bytes[0] === 0x52 && bytes[1] === 0x49 && bytes[2] === 0x46 && bytes[8] === 0x57 && bytes[9] === 0x45 && bytes[10] === 0x42 && bytes[11] === 0x50) return { ext: 'webp', mime: 'image/webp' };
  if (bytes[0] === 0x47 && bytes[1] === 0x49 && bytes[2] === 0x46) return { ext: 'gif', mime: 'image/gif' };
  return { ext: 'bin', mime: 'application/octet-stream' };
}

async function inspectSelection(selection) {
  const result = classifySelection(selection);
  for (const icon of result.icons) {
    if (icon.type !== 'INSTANCE') continue;
    try {
      const node = await figma.getNodeByIdAsync(icon.id);
      if (!node || node.type !== 'INSTANCE') continue;
      const component = await node.getMainComponentAsync();
      if (!component) continue;
      icon.componentName = component.name;
      if (ICON_WORDS.test(component.name || '')) {
        icon.confidence = 'high';
        icon.score = Math.max(icon.score, 95);
        icon.reason = `实例来源组件“${component.name}”符合图标特征`;
      } else if (NON_ICON_WORDS.test(component.name || '')) {
        icon.confidence = 'review';
        icon.score = Math.min(icon.score, 30);
        icon.reason = `实例来源组件“${component.name}”更像 UI 控件，请确认`;
      }
    } catch (error) {
      icon.confidence = 'review';
      icon.reason = '无法读取实例来源组件，请人工确认';
    }
  }
  result.icons.sort((a, b) => b.score - a.score || a.name.localeCompare(b.name));
  result.summary = {
    images: result.images.length,
    highConfidenceIcons: result.icons.filter(item => item.confidence === 'high').length,
    reviewIcons: result.icons.filter(item => item.confidence === 'review').length,
  };
  result.limits = { maxExportItems: MAX_EXPORT_ITEMS };
  return result;
}

async function exportAsset(item) {
  if (item.kind === 'image') {
    const image = figma.getImageByHash(item.imageRef);
    if (!image) throw new Error('原始图片引用已失效');
    const bytes = await image.getBytesAsync();
    const format = detectImageFormat(bytes);
    return { name: uniqueFilename(item, format.ext), mime: format.mime, bytes, source: { occurrences: item.occurrences || [] } };
  }
  const node = await figma.getNodeByIdAsync(item.id);
  if (!node || !('exportAsync' in node)) throw new Error('图标节点不存在或不可导出');
  const bytes = await node.exportAsync({ format: 'SVG' });
  return { name: uniqueFilename(item, 'svg'), mime: 'image/svg+xml', bytes, source: item.source };
}

function isEmptyLayerExportError(error) {
  return /failed to export node[\s\S]*visible layers/i.test(String(error && (error.message || error)));
}

// FIGMA RUNTIME
figma.showUI(__html__, { width: 600, height: 720, themeColors: true });

async function inspectCurrentSelection() {
  const result = await inspectSelection(figma.currentPage.selection);
  figma.ui.postMessage({ type: 'inspection', result });
}

// 打开插件时保持空状态；用户改变画布选区后再自动扫描。
figma.on('selectionchange', () => {
  inspectCurrentSelection();
});

figma.ui.onmessage = async msg => {
  try {
    if (msg.type === 'inspect') {
      await inspectCurrentSelection();
      return;
    }
    if (msg.type === 'export') {
      if (!Array.isArray(msg.items) || msg.items.length === 0) throw new Error('没有选择素材');
      if (msg.items.length > MAX_EXPORT_ITEMS) throw new Error(`一次最多导出 ${MAX_EXPORT_ITEMS} 个素材，请缩小选区或分批导出`);
      const output = [];
      for (let index = 0; index < msg.items.length; index++) {
        const item = msg.items[index];
        figma.ui.postMessage({ type: 'export-progress', current: index + 1, total: msg.items.length, name: item.name });
        try {
          const result = await exportAsset(item);
          output.push({ ...result, bytes: Array.from(result.bytes), sourceItem: item });
        } catch (error) {
          if (isEmptyLayerExportError(error)) {
            output.push({ skipped: true, skipReason: '节点没有可见图层', sourceItem: item });
          } else {
            output.push({ name: uniqueFilename(item, item.kind === 'image' ? 'bin' : 'svg'), error: String(error.message || error), sourceItem: item });
          }
        }
      }
      figma.ui.postMessage({ type: 'exported', output });
    }
  } catch (error) {
    figma.ui.postMessage({ type: 'error', message: String(error.message || error) });
  }
};

figma.ui.postMessage({ type: 'ready' });
